// 1025.✅ Divisor Game

class Solution
{
public:
    bool divisorGame(int n)
    {

        if (n % 2 == 0)
            return true;
        return false;
    }
};